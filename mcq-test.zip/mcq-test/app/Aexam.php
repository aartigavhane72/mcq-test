<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aexam extends Model
{
    protected $primaryKey = 'examcode';
    protected $table = 'exam';
    
}
