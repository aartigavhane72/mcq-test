<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ref_result extends Model
{
    protected $table = 'ref_result';

    protected $guarded = [];
}
