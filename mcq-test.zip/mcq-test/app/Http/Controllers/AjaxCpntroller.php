<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AjaxCpntroller extends Controller
{
    //
}
